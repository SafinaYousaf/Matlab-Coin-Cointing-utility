function [Bimage] = grayTObinary( Oimage )
%Threshold the image to get a binary image
%using im2bw()
  normalizedThresholdValue = 0.4; % In range 0 to 1.
  thresholdValue = normalizedThresholdValue * max(max(Oimage)); % Gray Levels.
 Bimage = im2bw(Oimage, normalizedThresholdValue);       % One way to threshold to binary
Bimage = imfill(Bimage, 'holes');
end