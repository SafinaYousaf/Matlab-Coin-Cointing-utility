function [image] = convert( fullFileName )
%convert image into array
Image= imread(fullFileName);
% Check to make sure that it is grayscale, just in case the user substituted their own image.
[rows, columns, numberOfColorChannels] = size(Image);
if numberOfColorChannels > 1
	% Do the conversion from RGB yo grayScale
	image = rgb2gray(Image);
else
end
end