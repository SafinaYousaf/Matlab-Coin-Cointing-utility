%Function ourblob -------- it count the image in picture using blob
%detection means it looks for edge...
%Input -------- Image containing Pakistani rupees contaning
%            coin of five and one
%WORKING OVERVIEW---------- first of all if iamge is not grayscle "convert"
%utility is called to make is grayscale then another utility is used to
%convert it into binary image then blobs are detected and labeled 
%at the end the blob that are representing only coins are cropped and
%finaly coins are counted
%Output=----------- count of coins and Amount in rupees
function [count_of_coins, AmountInrupees] = ourblob(k)


clc; % Clear command window.
fprintf('Running ourblob...\n'); % Message sent to command window.
captionFontSize = 13;



% Read in a standard MATLAB demo image of coins (US nickles and dimes, which are 5 cent and 10 cent coins)
standardFileName = k;
folderName = fileparts(which(standardFileName)); % Determine where demo folder is (works with all versions).
BaseFile = fullfile(folderName, standardFileName);
%what if file is not present
%then a dialog box appear to givwe warning and our blob stops running
if ~exist(BaseFile, 'file')
	% Look on the search path.
	if ~exist(standardFileName, 'file')
		%if not found
		% Alert user
		warningMessage = sprintf('Error: the input image file\n%s\nwas not found.\nClick OK to exit the demo.', BaseFile);
		uiwait(warndlg(warningMessage));
		fprintf(1, 'Finished running BlobsDemo.m.\n');
		return;
	end
	% Found it on the search path.  Construct the file name.
	BaseFile = standardFileName; % Note: don't prepend the folder.
end
%if image found then
%user-defined function to check if image is not grayscale then convert it
%into one.
originalImage = convert(BaseFile); 
% Display the grayscale image.
subplot(3, 3, 1);
imshow(originalImage);
% Maximize the figure window.
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
% to display figure right now
drawnow;
capt = sprintf('Original "coins" image');
title(capt, 'FontSize', captionFontSize);
axis image; % Make sure image is not artificially stretched because of screen's aspect ratio.


%user-defined function to convert grayscale image
%into binary one.
binaryImage = grayTObinary(originalImage); %OUR Function

% Display the binary image.
subplot(3, 3, 2);
imshow(binaryImage); 
title('Binary Image, obtained by thresholding', 'FontSize', captionFontSize); 

% Identify individual blobs by seeing which pixels are connected to each other.
% Each group of connected pixels will be given a label, 
% Do connected components labeling with either bwlab ()
labeled = bwlabel(binaryImage, 4);     % Label each blob so we can make measurements of it
% labeledImage is an integer-valued image where all pixels in the blobs have values of 1, or 2, or 3, or ... etc.
subplot(3, 3, 3);
imshow(labeled, []);  % Show the gray scale image.
title('Labeled Image, from bwlabel()', 'FontSize', captionFontSize);


% Get all the blob properties.  
blobperimeters = regionprops(labeled, originalImage, 'all');
numberOfBlobs = size(blobperimeters, 1);

% bwboundaries() returns a cell array
% Plot the borders of all the coins on the original grayscale image using 
%the coordinates returned by bwboundaries.
subplot(3, 3, 5);
imshow(originalImage);
title('Outlines, from bwboundaries()', 'FontSize', captionFontSize); 
axis image; % Make sure image is not artificially stretched
hold on;
outerboundaries = bwboundaries(binaryImage);
noOfBoundaries = size(outerboundaries, 1);
for k = 1 : noOfBoundaries
	Boundary = outerboundaries{k};
	plot(Boundary(:,2), Boundary(:,1), 'red', 'LineWidth', 4);
end
hold off;
 %propertiesof blob


textFontSize = 14;	% Used to control size of "blob number" labels put atop the image.
labelShiftX = -7;	% Used to align the labels in the centers of the coins.
blobECD = zeros(1, numberOfBlobs);
% this function will print the properties of blobs
%includung area
PropertiesOFblobs(numberOfBlobs, blobperimeters, originalImage);

%Now to distinguesh coin crop them and count them
message = sprintf('Would you like to crop out each coin to individual images?');
reply = questdlg(message, 'Extract Individual Images?', 'Yes', 'No', 'Yes');
% Note: reply will = '' for Upper right X, 'Yes' for Yes, and 'No' for No.
if strcmpi(reply, 'Yes')
    % Create a new figure window and  Maximize the figure window.
	figure;	
	set(gcf, 'Units','Normalized','OuterPosition',[0 0 1 1]);
    count = 0;  %number of coin in picture
    Amount = 0; %Amount in ruppes present in picture
	for k = 1 : numberOfBlobs           % Loop through all blobs.
		% Find the bounding box of each blob.
		thisBlobsBoundingBox = blobperimeters(k).BoundingBox;  % Get list of pixels in current blob.
		% Extract it out
		subImage = imcrop(originalImage, thisBlobsBoundingBox);
		% Determine if it's five rs , one rs or its a useless label
        %to avoid any garbage label keep area > 1000
		if blobperimeters(k).Area > 1000 && blobperimeters(k).Area < 626200.0
            %If coin detected is of amount 1 rs
           if blobperimeters(k).Area <  114639
			coinType = '1 rs';
            Amount = Amount + 1; 
           else
               %if coin detected is of amount 5
            coinType = '5 rs';
             Amount = Amount + 5;
            end
		% Display the image with  caption.
		subplot(3, 4, k);
		imshow(subImage);
		capt = sprintf('Coin #%d is a %s.\n\nArea = %d pixels', ...
			k, coinType,blobperimeters(k).Area);
		title(capt, 'FontSize', textFontSize);
        count = count +1;
        else
            k= k+1; %to skip any unwanted
        end
        
    end
end
AmountInrupees =Amount
count_of_coins= count 


end